Supplement for the nannyrust research paper.
Environment: Rust/cargo 1.75.0 (Cargo.lock regenerated; shipped lockfile v4 needs cargo>=1.78), Python 3.12.3, NumPy 2.4.4, SciPy 1.17.1,
scikit-learn 1.8.0, NannyML 0.13.1, 1 vCPU.
rust_harness/harness.rs  -> copy to nannyrust/examples/ and `cargo build --release --example harness`
patch/compat.rs          -> NumPy/NannyML-compatible JS/Hellinger (evaluation variant; add `pub mod compat;` to lib.rs); harness_with_compat.rs is the matching harness
scripts/e1..e5           -> experiments (paths assume /tmp/nannyrust and /tmp/patched builds; e1p.py uses the patched build)
results/*.csv            -> raw per-replicate outputs
