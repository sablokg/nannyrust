import numpy as np, pandas as pd, subprocess, json, warnings
warnings.filterwarnings("ignore")
from scipy.stats import chi2_contingency
from nannyml.drift.univariate.methods import (Chi2Statistic as NC, LInfinityDistance as NL,
    CategoricalJensenShannonDistance as NJS, CategoricalHellingerDistance as NH)
H="/tmp/nannyrust/target/release/examples/harness"
def nm(cls, ref, ana, **kw):
    m=cls(chunker=None, threshold=None); m._fit(pd.Series(ref,name='x')); return m, float(m._calculate(pd.Series(ana,name='x')))
def rust(ref,ana):
    open('/tmp/exp/r.txt','w').write("\n".join(ref)); open('/tmp/exp/a.txt','w').write("\n".join(ana))
    return json.loads(subprocess.check_output([H,'cat','/tmp/exp/r.txt','/tmp/exp/a.txt','1']))
def draw(rng,cats,p,n): return list(rng.choice(cats,size=n,p=np.array(p)/np.sum(p)))
def gen(sc,rng):
    plat=['NovaSeq','HiSeq','NextSeq','MiSeq']
    if sc=='C1 null (4 platforms)': return draw(rng,plat,[.4,.3,.2,.1],3000),draw(rng,plat,[.4,.3,.2,.1],3000)
    if sc=='C2 proportion shift (4 platforms)': return draw(rng,plat,[.4,.3,.2,.1],3000),draw(rng,plat,[.25,.3,.25,.2],3000)
    if sc=='C3 unseen category appears': return draw(rng,plat,[.4,.3,.2,.1],3000),draw(rng,plat+['NovaSeqX'],[.3,.25,.15,.1,.2],3000)
    if sc=='C4 binary feature (sex), df=1': return draw(rng,['F','M'],[.5,.5],3000),draw(rng,['F','M'],[.44,.56],3000)
    if sc=='C5 high cardinality (200 alleles/genes)':
        p=rng.dirichlet(np.ones(200)*.5); p2=rng.dirichlet(np.ones(200)*.5)*.3+p*.7; c=[f'g{i}' for i in range(200)]
        return draw(rng,c,p,5000),draw(rng,c,p2,5000)
    if sc=='C6 small n (150 vs 150)': return draw(rng,plat,[.4,.3,.2,.1],150),draw(rng,plat,[.25,.3,.25,.2],150)
SC=['C1 null (4 platforms)','C2 proportion shift (4 platforms)','C3 unseen category appears','C4 binary feature (sex), df=1','C5 high cardinality (200 alleles/genes)','C6 small n (150 vs 150)']
rows=[]
for si,sc in enumerate(SC):
    for rep in range(20):
        rng=np.random.default_rng(5000+100*si+rep); r,a=gen(sc,rng); R=rust(r,a)
        vr=pd.Series(r).value_counts(); va=pd.Series(a).value_counts(); tab=pd.concat([vr,va],axis=1).fillna(0)
        s_c=chi2_contingency(tab,correction=True); s_n=chi2_contingency(tab,correction=False)
        m,_=nm(NC,r,a)
        rows.append(dict(scenario=sc,rep=rep,df_rust=R['df'],df_sp=s_c[2],chi_rust=R['chi2'],chi_corr=s_c[0],chi_nocorr=s_n[0],p_rust=R['p'],p_corr=s_c[1],p_nocorr=s_n[1],
          linf_rust=R['linf'],linf_nm=nm(NL,r,a)[1],js_rust=R['js'],js_nm=nm(NJS,r,a)[1],h_rust=R['hellinger'],h_nm=nm(NH,r,a)[1]))
d=pd.DataFrame(rows); d.to_csv('/tmp/exp/e2.csv',index=False)
d['dchi_nocorr']=(d.chi_rust-d.chi_nocorr).abs(); d['dchi_corr']=(d.chi_rust-d.chi_corr).abs()
d['dp_nocorr']=(d.p_rust-d.p_nocorr).abs(); d['dp_corr']=(d.p_rust-d.p_corr).abs()
d['dlinf']=(d.linf_rust-d.linf_nm).abs(); d['jsr']=d.js_rust/d.js_nm; d['dh']=(d.h_rust-d.h_nm).abs()
d['dfmatch']=d.df_rust==d.df_sp; d['dj_adj']=(d.js_rust/np.sqrt(np.log(2))-d.js_nm).abs()
g=d.groupby('scenario',sort=False)
o=pd.DataFrame({'df agrees':g.dfmatch.mean(),'max|dchi2| vs scipy(no corr)':g.dchi_nocorr.max(),'max|dchi2| vs scipy(Yates)':g.dchi_corr.max(),'max|dp| vs no corr':g.dp_nocorr.max(),'max|dp| vs Yates (NannyML default)':g.dp_corr.max(),
 'max|dLinf|':g.dlinf.max(),'JS ratio (mean)':g.jsr.mean(),'max|dJS| after /sqrt(ln2)':g.dj_adj.max(),'max|dH|':g.dh.max()})
pd.set_option('display.width',250,'display.max_columns',30,'display.float_format','{:.3g}'.format); print(o.T.to_string())
