import numpy as np, pandas as pd, subprocess, json, warnings
warnings.filterwarnings("ignore")
from scipy.stats import ks_2samp, wasserstein_distance
from nannyml.drift.univariate.methods import (ContinuousJensenShannonDistance as NJS,
    ContinuousHellingerDistance as NH, KolmogorovSmirnovStatistic as NKS, WassersteinDistance as NW)
H="/tmp/nannyrust/target/release/examples/harness"
def nm(cls, ref, ana):
    m=cls(chunker=None, threshold=None); m._fit(pd.Series(ref,name='x')); return float(m._calculate(pd.Series(ana,name='x')))
def rust(ref, ana):
    ref.astype('<f8').tofile('/tmp/exp/r.f64'); ana.astype('<f8').tofile('/tmp/exp/a.f64')
    return json.loads(subprocess.check_output([H,'cont','/tmp/exp/r.f64','/tmp/exp/a.f64','1']))
def gen(sc, rng):
    if sc=='S1 null (n=5000, log-expr N(5,1.5))': return rng.normal(5,1.5,5000), rng.normal(5,1.5,5000)
    if sc=='S2 batch mean shift +0.5 SD units 0.33': return rng.normal(5,1.5,5000), rng.normal(5.5,1.5,5000)
    if sc=='S3 variance inflation (SD 1.5->2.5)': return rng.normal(5,1.5,5000), rng.normal(5,2.5,5000)
    if sc=='S4 composition shift (unimodal -> bimodal)':
        a=np.where(rng.random(5000)<.5, rng.normal(3,.8,5000), rng.normal(7,.8,5000)); return rng.normal(5,1.5,5000), a
    if sc=='S5 heavy-tailed coverage (lognormal, +20% scale)': return rng.lognormal(3,.6,5000), rng.lognormal(3,.6,5000)*1.2
    if sc=='S6 integer read counts (NB, mean 30 -> 36)':
        f=lambda mu,n: rng.negative_binomial(10, 10/(10+mu), n).astype(float); return f(30,5000), f(36,5000)
    if sc=='S7 small n (200 vs 200, shift 0.5)': return rng.normal(5,1.5,200), rng.normal(5.5,1.5,200)
    if sc=='S8 analysis exceeds reference range': return rng.normal(5,1,5000), rng.normal(5.5,2,5000)
    if sc=='S9 large n (50k vs 50k, shift 0.1)': return rng.normal(5,1.5,50000), rng.normal(5.1,1.5,50000)
SC=['S1 null (n=5000, log-expr N(5,1.5))','S2 batch mean shift +0.5 SD units 0.33','S3 variance inflation (SD 1.5->2.5)','S4 composition shift (unimodal -> bimodal)','S5 heavy-tailed coverage (lognormal, +20% scale)','S6 integer read counts (NB, mean 30 -> 36)','S7 small n (200 vs 200, shift 0.5)','S8 analysis exceeds reference range','S9 large n (50k vs 50k, shift 0.1)']
rows=[]
for si,sc in enumerate(SC):
    for rep in range(20):
        rng=np.random.default_rng(1000*si+rep); r,a=gen(sc,rng); R=rust(r,a)
        rows.append(dict(scenario=sc,rep=rep,
          ks_rust=R['ks'],ks_scipy=ks_2samp(r,a).statistic,ks_nm=nm(NKS,r,a),
          w_rust=R['wasserstein'],w_scipy=wasserstein_distance(r,a),w_nm=nm(NW,r,a),
          js_rust=R['js'],js_nm=nm(NJS,r,a),h_rust=R['hellinger'],h_nm=nm(NH,r,a),bins_rust=R['n_bins'],
          bins_np=len(np.histogram_bin_edges(r,'doane'))-1))
df=pd.DataFrame(rows); df.to_csv('/tmp/exp/e1.csv',index=False)
df['d_ks_scipy']=(df.ks_rust-df.ks_scipy).abs(); df['d_ks_nm']=(df.ks_rust-df.ks_nm).abs()
df['d_w_scipy']=(df.w_rust-df.w_scipy).abs(); df['d_w_nm']=(df.w_rust-df.w_nm).abs()
df['js_ratio']=df.js_rust/df.js_nm; df['d_js']=(df.js_rust-df.js_nm).abs(); df['d_js_adj']=(df.js_rust/np.sqrt(np.log(2))-df.js_nm).abs()
df['d_h']=(df.h_rust-df.h_nm).abs(); df['bin_diff']=df.bins_rust-df.bins_np
g=df.groupby('scenario',sort=False)
out=pd.DataFrame({'max|dKS| vs scipy':g.d_ks_scipy.max(),'max|dW| vs scipy':g.d_w_scipy.max(),'max|dKS| vs NML':g.d_ks_nm.max(),'max|dW| vs NML':g.d_w_nm.max(),
 'JS ratio mean':g.js_ratio.mean(),'max|dJS|':g.d_js.max(),'max|dJS| after /sqrt(ln2)':g.d_js_adj.max(),'max|dH|':g.d_h.max(),'median dH':g.d_h.median(),'bins Rust-NP (mean)':g.bin_diff.mean(),'reps w/ same bins':g.bin_diff.apply(lambda s:(s==0).mean())})
pd.set_option('display.width',250,'display.max_columns',30,'display.float_format','{:.3g}'.format)
print(out.T.to_string())
