import numpy as np, pandas as pd, subprocess, json
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
H="/tmp/nannyrust/target/release/examples/harness"
def rust(yt,yp,pr):
    yt.astype('u1').tofile('/tmp/exp/yt'); yp.astype('u1').tofile('/tmp/exp/yp'); pr.astype('<f8').tofile('/tmp/exp/pr')
    return json.loads(subprocess.check_output([H,'perf','/tmp/exp/yt','/tmp/exp/yp','/tmp/exp/pr','1']))
sig=lambda z:1/(1+np.exp(-z)); logit=lambda p:np.log(p/(1-p))
def sim(sc,rng,n=2000):
    if sc=='P1 calibrated, no shift': z=rng.normal(-0.5,1.8,n); p=sig(z); y=rng.random(n)<p
    if sc=='P2 covariate shift, calibration holds': z=rng.normal(0.8,1.8,n); p=sig(z); y=rng.random(n)<p
    if sc=='P3 concept shift (overconfident model)': z=rng.normal(-0.5,1.8,n); p=sig(z); y=rng.random(n)<sig(0.5*z)
    if sc=='P4 concept shift (underconfident model)': z=rng.normal(-0.5,1.8,n); p=sig(0.5*z); y=rng.random(n)<sig(z)
    return y, (p>=0.5), p
SC=['P1 calibrated, no shift','P2 covariate shift, calibration holds','P3 concept shift (overconfident model)','P4 concept shift (underconfident model)']
rows=[]; chk=[]
for si,sc in enumerate(SC):
    for rep in range(100):
        rng=np.random.default_rng(9000+1000*si+rep); y,yp,p=sim(sc,rng)
        if rep<30: p=np.round(p,2)+0.0; p=np.clip(p,0.01,0.99)  # induce AUC ties in some reps
        R=rust(y,yp,p); re=R['realised']; es=R['cbpe']
        tn,fp,fn,tp=confusion_matrix(y,yp).ravel()
        chk.append(dict(auc=abs(R['auc']-roc_auc_score(y,p)),acc=abs(re['acc']-accuracy_score(y,yp)),prec=abs(re['prec']-precision_score(y,yp,zero_division=0)),rec=abs(re['rec']-recall_score(y,yp,zero_division=0)),spec=abs(re['spec']-tn/(tn+fp)),f1=abs(re['f1']-f1_score(y,yp,zero_division=0))))
        for k in ['acc','prec','rec','spec','f1']: rows.append(dict(scenario=sc,rep=rep,metric=k,real=re[k],est=es[k]))
c=pd.DataFrame(chk); print("Realised-metric & AUC agreement with scikit-learn (max abs diff over",len(c),"datasets):"); print(c.max().to_string())
d=pd.DataFrame(rows); d['err']=d.est-d.real; d.to_csv('/tmp/exp/e3.csv',index=False)
t=d.groupby(['scenario','metric'],sort=False).err.agg(bias='mean',mae=lambda s:s.abs().mean()).unstack()
pd.set_option('display.width',250,'display.float_format','{:.4f}'.format); print(t.to_string())
