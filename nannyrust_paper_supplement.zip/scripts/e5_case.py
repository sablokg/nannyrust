import numpy as np, pandas as pd, subprocess, json, warnings
warnings.filterwarnings("ignore")
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.isotonic import IsotonicRegression
H="/tmp/nannyrust/target/release/examples/harness"
X,y=load_breast_cancer(return_X_y=True,as_frame=True); names=list(X.columns); y=(1-y.values)  # 1 = malignant
def run(ref,ana):
    ref.astype('<f8').tofile('/tmp/exp/r.f64'); ana.astype('<f8').tofile('/tmp/exp/a.f64')
    return json.loads(subprocess.check_output([H,'cont','/tmp/exp/r.f64','/tmp/exp/a.f64','1']))
def perf(yt,yp,pr):
    yt.astype('u1').tofile('/tmp/exp/yt'); yp.astype('u1').tofile('/tmp/exp/yp'); pr.astype('<f8').tofile('/tmp/exp/pr')
    return json.loads(subprocess.check_output([H,'perf','/tmp/exp/yt','/tmp/exp/yp','/tmp/exp/pr','1']))
size=[i for i,n in enumerate(names) if any(k in n for k in ['radius','perimeter','area'])]
conds={'none':lambda A,rng:A,'scale x1.15 (size features)':lambda A,rng:scale(A,1.15),'scale x1.40 (size features)':lambda A,rng:scale(A,1.40)}
def scale(A,f): A=A.copy(); A[:,size]*=f; return A
crit=1.358*np.sqrt((190+189)/(190*189))
rows=[]; fl=[]
for rep in range(100):
    rng=np.random.default_rng(rep); idx=rng.permutation(len(y)); tr,rf,an=idx[:190],idx[190:380],idx[380:]
    mdl=make_pipeline(StandardScaler(),LogisticRegression(max_iter=2000)).fit(X.values[tr],y[tr])
    iso=IsotonicRegression(y_min=0.001,y_max=0.999,out_of_bounds='clip').fit(mdl.predict_proba(X.values[rf])[:,1],y[rf])
    for c,fn in conds.items():
        A=fn(X.values[an],rng); p=iso.predict(mdl.predict_proba(A)[:,1]); yp=(p>=0.5)
        P=perf(y[an],yp,p); 
        ks=[run(X.values[rf][:,j],A[:,j])['ks'] for j in range(30)]
        rows.append(dict(rep=rep,cond=c,real_acc=P['realised']['acc'],est_acc=P['cbpe']['acc'],real_rec=P['realised']['rec'],est_rec=P['cbpe']['rec'],auc=P['auc'],
                         n_flag=int(np.sum(np.array(ks)>crit)),flag_size=int(np.sum(np.array(ks)[size]>crit)),flag_other=int(np.sum(np.delete(np.array(ks),size)>crit)),mean_ks_size=np.mean(np.array(ks)[size]),mean_ks_other=np.mean(np.delete(np.array(ks),size))))
d=pd.DataFrame(rows); d.to_csv('/tmp/exp/e5.csv',index=False)
d['err']=d.est_acc-d.real_acc
g=d.groupby('cond',sort=False)
pd.set_option('display.width',250,'display.float_format','{:.3f}'.format)
print("KS crit",crit,"n size features",len(size))
print(pd.DataFrame({'real acc':g.real_acc.mean(),'CBPE acc':g.est_acc.mean(),'bias':g.err.mean(),'MAE':g.err.apply(lambda s:s.abs().mean()),'AUC':g.auc.mean(),
  'features flagged (of 30)':g.n_flag.mean(),'size feats flagged (of %d)'%len(size):g.flag_size.mean(),'other flagged (of %d)'%(30-len(size)):g.flag_other.mean(),'mean KS size':g.mean_ks_size.mean(),'mean KS other':g.mean_ks_other.mean()}).T.to_string())
