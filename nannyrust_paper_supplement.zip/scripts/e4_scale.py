import numpy as np, pandas as pd, subprocess, json, time, warnings, re, resource
warnings.filterwarnings("ignore")
from scipy.stats import ks_2samp, wasserstein_distance
from nannyml.drift.univariate.methods import (ContinuousJensenShannonDistance as NJS, ContinuousHellingerDistance as NH, KolmogorovSmirnovStatistic as NKS, WassersteinDistance as NW)
H="/tmp/nannyrust/target/release/examples/harness"
def tm(f,reps=3):
    ts=[]
    for _ in range(reps): t=time.perf_counter(); f(); ts.append(time.perf_counter()-t)
    return sorted(ts)[len(ts)//2]
rows=[]
for n in [10**3,10**4,10**5,10**6,10**7]:
    rng=np.random.default_rng(n); r=rng.normal(5,1.5,n); a=rng.normal(5.3,1.6,n)
    r.astype('<f8').tofile('/tmp/exp/r.f64'); a.astype('<f8').tofile('/tmp/exp/a.f64')
    reps=5 if n<=10**5 else 3
    o=subprocess.run([H,'cont','/tmp/exp/r.f64','/tmp/exp/a.f64',str(reps)],capture_output=True,text=True)
    R=json.loads(o.stdout); rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss/1024
    sr=pd.Series(r,name='x'); sa=pd.Series(a,name='x'); ms={}
    for k,c in [('ks',NKS),('w',NW),('js',NJS),('h',NH)]:
        m=c(chunker=None,threshold=None); m._fit(sr); ms[k]=m
    row=dict(n=n,rust_ks=R['t_ks']/1e9,rust_w=R['t_w']/1e9,rust_js=R['t_js']/1e9,rust_h=R['t_h']/1e9,rust_rss_mb=rss,
      scipy_ks=tm(lambda:ks_2samp(r,a),reps),scipy_w=tm(lambda:wasserstein_distance(r,a),reps),
      nml_ks=tm(lambda:ms['ks']._calculate(sa),reps),nml_w=tm(lambda:ms['w']._calculate(sa),reps),nml_js=tm(lambda:ms['js']._calculate(sa),reps),nml_h=tm(lambda:ms['h']._calculate(sa),reps))
    rows.append(row); print(row,flush=True)
pd.DataFrame(rows).to_csv('/tmp/exp/e4.csv',index=False)
