//! NumPy/NannyML-compatible histogram drift metrics (evaluation variant).
fn doane_edges(x: &[f64]) -> Vec<f64> {
    let n = x.len() as f64;
    let mn = x.iter().cloned().fold(f64::INFINITY, f64::min);
    let mx = x.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    let ptp = mx - mn;
    let mean = x.iter().sum::<f64>() / n;
    let sd = (x.iter().map(|v| (v - mean).powi(2)).sum::<f64>() / n).sqrt();
    let mut nb = 1usize;
    if n > 2.0 && sd > 0.0 && ptp > 0.0 {
        let g1 = x.iter().map(|v| ((v - mean) / sd).powi(3)).sum::<f64>() / n;
        let sg1 = (6.0 * (n - 2.0) / ((n + 1.0) * (n + 3.0))).sqrt();
        let width = ptp / (1.0 + n.log2() + (1.0 + g1.abs() / sg1).log2());
        nb = ((ptp / width).ceil() as usize).max(1);
    }
    let mut e: Vec<f64> = (0..=nb).map(|i| mn + ptp * i as f64 / nb as f64).collect();
    e[nb] = mx; // numpy.linspace pins the final edge exactly
    e
}
fn hist(x: &[f64], e: &[f64]) -> Vec<f64> {
    let nb = e.len() - 1;
    let mut c = vec![0usize; nb];
    for &v in x {
        if v < e[0] || v > e[nb] { continue; } // np.histogram ignores out-of-range
        let mut i = e.partition_point(|&b| b <= v).saturating_sub(1);
        if i >= nb { i = nb - 1; } // last bin closed on the right
        c[i] += 1;
    }
    c.into_iter().map(|k| k as f64 / x.len() as f64).collect()
}
fn dists(r: &[f64], a: &[f64]) -> (Vec<f64>, Vec<f64>) {
    let e = doane_edges(r);
    let mut p = hist(r, &e);
    let mut q = hist(a, &e);
    let left = 1.0 - q.iter().sum::<f64>();
    if left > 1e-12 { q.push(left); p.push(0.0); }
    (p, q)
}
fn kl(p: &[f64], q: &[f64]) -> f64 { p.iter().zip(q).map(|(&a, &b)| if a == 0.0 { 0.0 } else { a * (a / b).ln() }).sum() }
pub fn jensen_shannon_base2(r: &[f64], a: &[f64]) -> f64 {
    let (p, q) = dists(r, a);
    let m: Vec<f64> = p.iter().zip(&q).map(|(a, b)| 0.5 * (a + b)).collect();
    ((0.5 * kl(&p, &m) + 0.5 * kl(&q, &m)) / std::f64::consts::LN_2).max(0.0).sqrt()
}
pub fn hellinger(r: &[f64], a: &[f64]) -> f64 {
    let (p, q) = dists(r, a);
    (p.iter().zip(&q).map(|(a, b)| (a.sqrt() - b.sqrt()).powi(2)).sum::<f64>() / 2.0).sqrt()
}
