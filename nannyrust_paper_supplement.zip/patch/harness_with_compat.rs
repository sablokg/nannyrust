//! Benchmark / validation harness (not part of the library API).
//! cont <ref.f64> <ana.f64> [reps]   -> JSON with 4 continuous metrics + timings (ns, median)
//! cat  <ref.txt> <ana.txt> [reps]   -> JSON with categorical metrics + timings
//! perf <ytrue.u8> <ypred.u8> <proba.f64> -> JSON with realised, CBPE and AUC
use nannyml_metrics::{binning, categorical, continuous, performance};
use std::{env, fs, time::Instant};

fn read_f64(p: &str) -> Vec<f64> {
    fs::read(p).unwrap().chunks_exact(8).map(|c| f64::from_le_bytes(c.try_into().unwrap())).collect()
}
fn read_u8b(p: &str) -> Vec<bool> { fs::read(p).unwrap().into_iter().map(|b| b != 0).collect() }
fn read_lines(p: &str) -> Vec<String> { fs::read_to_string(p).unwrap().lines().map(|s| s.to_string()).collect() }
fn med_time<T>(reps: usize, mut f: impl FnMut() -> T) -> (T, u128) {
    let mut ts = vec![]; let mut out = None;
    for _ in 0..reps { let t = Instant::now(); out = Some(f()); ts.push(t.elapsed().as_nanos()); }
    ts.sort(); (out.unwrap(), ts[ts.len() / 2])
}
fn main() {
    let a: Vec<String> = env::args().collect();
    let reps: usize = a.get(4).and_then(|s| s.parse().ok()).unwrap_or(3);
    match a[1].as_str() {
        "cont" => {
            let (r, x) = (read_f64(&a[2]), read_f64(&a[3]));
            let (ks, t1) = med_time(reps, || continuous::kolmogorov_smirnov(&r, &x));
            let (w, t2) = med_time(reps, || continuous::wasserstein(&r, &x));
            let (js, t3) = med_time(reps, || continuous::jensen_shannon(&r, &x));
            let (h, t4) = med_time(reps, || continuous::hellinger(&r, &x));
            let (jc, hc) = (nannyml_metrics::compat::jensen_shannon_base2(&r, &x), nannyml_metrics::compat::hellinger(&r, &x));
            let nb = binning::reference_bin_edges(&r).len() - 1;
            println!("{{\"ks\":{ks:.12e},\"wasserstein\":{w:.12e},\"js\":{js:.12e},\"hellinger\":{h:.12e},\"js_compat\":{jc:.12e},\"h_compat\":{hc:.12e},\"n_bins\":{nb},\"t_ks\":{t1},\"t_w\":{t2},\"t_js\":{t3},\"t_h\":{t4}}}");
        }
        "cat" => {
            let (r, x) = (read_lines(&a[2]), read_lines(&a[3]));
            let (c, t1) = med_time(reps, || categorical::chi2(&r, &x));
            let (l, t2) = med_time(reps, || categorical::l_infinity(&r, &x));
            let (js, t3) = med_time(reps, || categorical::jensen_shannon(&r, &x));
            let (h, t4) = med_time(reps, || categorical::hellinger(&r, &x));
            println!("{{\"chi2\":{:.12e},\"df\":{},\"p\":{:.12e},\"linf\":{l:.12e},\"js\":{js:.12e},\"hellinger\":{h:.12e},\"t_chi2\":{t1},\"t_l\":{t2},\"t_js\":{t3},\"t_h\":{t4}}}", c.statistic, c.degrees_of_freedom, c.p_value);
        }
        "perf" => {
            let (yt, yp, pr) = (read_u8b(&a[2]), read_u8b(&a[3]), read_f64(&a[4]));
            let cm = performance::ConfusionMatrix::from_labels(&yt, &yp);
            let est = performance::cbpe_estimate(&yp, &pr);
            let (auc, t) = med_time(reps.max(1), || performance::roc_auc(&yt, &pr));
            let f = |m: &performance::ConfusionMatrix| format!("{{\"acc\":{:.12e},\"prec\":{:.12e},\"rec\":{:.12e},\"spec\":{:.12e},\"f1\":{:.12e}}}", m.accuracy(), m.precision(), m.recall(), m.specificity(), m.f1());
            println!("{{\"realised\":{},\"cbpe\":{},\"auc\":{auc:.12e},\"t_auc\":{t}}}", f(&cm), f(&est));
        }
        _ => panic!("mode"),
    }
}
